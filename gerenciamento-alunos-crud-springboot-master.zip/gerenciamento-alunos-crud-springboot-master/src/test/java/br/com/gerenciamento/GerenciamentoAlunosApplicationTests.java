package br.com.gerenciamento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerenciamentoAlunosApplicationTests {

    @Test
    void contextLoads() {
    }

}
