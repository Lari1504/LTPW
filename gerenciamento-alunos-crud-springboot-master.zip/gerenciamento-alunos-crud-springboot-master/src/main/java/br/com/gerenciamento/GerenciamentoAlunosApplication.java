package br.com.gerenciamento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GerenciamentoAlunosApplication {

    public static void main(String[] args) {
        SpringApplication.run(GerenciamentoAlunosApplication.class, args);
    }
}
