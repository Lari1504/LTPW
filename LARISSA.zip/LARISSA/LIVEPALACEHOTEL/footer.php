<footer class="spacer">
        <div class="container">
            <div class="row">
                <div class="col-sm-5">
                    <h4>Live Palace Hotel</h4>
                    <p>O melhor local em Barcelona, O Live Palace Hotel está localizado a apenas 50m do centro de Barcelona e dispõe de piscina ao ar livre com vista da cidade.</p>
                </div>              
                 
                 <div class="col-sm-3">
                    <h4>Principais links</h4>
                    <ul class="list-unstyled">
                    <li><a href="index.php">Início</a></li>
                    <li><a href="QuartosePreços.php">Quartos e Preços</a></li>        
                    <li><a href="Historia.php">Minha Historia</a></li>
                    <li><a href="Galeria.php">Galeria</a></li>
                    <li><a href="Contato.php">Contato</a></li>
                    </ul>
                </div>
                 <div class="col-sm-4 subscribe">
                    <h4>E-mail: </h4>
                    <div class="input-group">
                    <input type="text" class="form-control" placeholder="Digite o seu e-mail:">
                    <span class="input-group-btn">
                    <button class="btn btn-default" type="button">Enviar</button>
                    </span>
                    </div>
                    <div class="social">
                    <a href="https://www.facebook.com/profile.php?id=100089201002428"><i class="fa fa-facebook-square" data-toggle="tooltip" data-placement="top" data-original-title="facebook"></i></a>
                    <a href="https://www.instagram.com/livepalace2023/"><i class="fa fa-instagram"  data-toggle="tooltip" data-placement="top" data-original-title="instragram"></i></a>
                    </div>
                </div>
            </div>
            <!--/.row--> 
        </div>
        <!--/.container-->    
    
    <!--/.footer-bottom--> 
</footer>

<div class="text-center copyright">Feito pela Programadora Larissa</a></div>

<a href="#home" class="toTop scroll"><i class="fa fa-angle-up"></i></a>




<!-- The Bootstrap Image Gallery lightbox, should be a child element of the document body -->
<div id="blueimp-gallery" class="blueimp-gallery blueimp-gallery-controls">
    <!-- The container for the modal slides -->
    <div class="slides"></div>
    <!-- Controls for the borderless lightbox -->
    <h3 class="title">title</h3>
    <a class="prev">‹</a>
    <a class="next">›</a>
    <a class="close">×</a>
    <!-- The modal dialog, which will be used to wrap the lightbox content -->    
</div>





<script src="assets/jquery.js"></script>

<!-- wow script -->
<script src="assets/wow/wow.min.js"></script>

<!-- uniform -->
<script src="assets/uniform/js/jquery.uniform.js"></script>


<!-- boostrap -->
<script src="assets/bootstrap/js/bootstrap.js" type="text/javascript" ></script>

<!-- jquery mobile -->
<script src="assets/mobile/touchSwipe.min.js"></script>

<!-- jquery mobile -->
<script src="assets/respond/respond.js"></script>

<!-- gallery -->
<script src="assets/gallery/jquery.blueimp-gallery.min.js"></script>


<!-- custom script -->
<script src="assets/script.js"></script>

</body>
</html>





