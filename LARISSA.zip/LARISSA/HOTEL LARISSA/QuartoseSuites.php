<?php include 'header.php';?>

<div class="container">

<h2>Quartos e Suites</h2>


<!-- form -->

<div class="row">
  <div class="col-sm-6 wowload fadeInUp"><div class="rooms"><img src="images/quartoesuite (1).jpg" class="img-responsive"><div class="info"><h3>Quarto Simples</h3><p> Quarto Super confotaveis</p><p>€200,00</p>
  <a href="room-details.php" class="btn btn-default">Fazer o Checkin</a></div></div></div>
  <div class="col-sm-6 wowload fadeInUp"><div class="rooms"><img src="images/quartoesuite (2).jpg" class="img-responsive"><div class="info"><h3>Quarto Composto com Area de Piscina</h3><p>  Quarto Super confotaveis</p> <p>€500,00</p><a href="room-details.php" class="btn btn-default">Fazer o Checkin</a></div></div></div>
  <div class="col-sm-6 wowload fadeInUp"><div class="rooms"><img src="images/quartoesuite (3).jpg" class="img-responsive"><div class="info"><h3>Quarto simples com 2 camas</h3><p>  Quarto Super confotaveis</p><p>€120,00</p><a href="room-details.php" class="btn btn-default">Fazer o Checkin</a></div></div></div>
  <div class="col-sm-6 wowload fadeInUp"><div class="rooms"><img src="images/quartoesuite (4).jpg" class="img-responsive"><div class="info"><h3>Quarto simples com 2 camas e sala</h3><p> Quarto Super confotaveis</p><p>€150,00</p><a href="room-details.php" class="btn btn-default">Fazer o Checkin</a></div></div></div>
  <div class="col-sm-6 wowload fadeInUp"><div class="rooms"><img src="images/quartoesuite (5).jpg" class="img-responsive"><div class="info"><h3>Quarto com escritorio e vista para a cidade</h3><p> Quarto Super confotaveis</p><P>€220,00</P><a href="room-details.php" class="btn btn-default">Fazer o Checkin</a></div></div></div>
  <div class="col-sm-6 wowload fadeInUp"><div class="rooms"><img src="images/quartoesuite (6).jpg" class="img-responsive"><div class="info"><h3>Quarto de casal</h3><p> Quarto Super confotaveis</p><p>€215,00</p><a href="room-details.php" class="btn btn-default">Fazer o Checkin</a></div></div></div>
</div>

</div>
<?php include 'footer.php';?>