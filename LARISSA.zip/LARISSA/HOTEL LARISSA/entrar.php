<?php
    session_start();
   
?>
<!DOCTYPE html>
<html>
 

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Live Palace Hotel</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="bulma.min.css" />
    <link rel="stylesheet" type="text/css" href="login.css">

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Live Palace Hotel</title>
    <link href='http://fonts.googleapis.com/css?family=Raleway:300,500,800|Old+Standard+TT' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Raleway:300,500,800' rel='stylesheet' type='text/css'>

    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />
    <link type="text/css" rel="stylesheet" href="assets/uniform/css/uniform.default.min.css" />
    <link rel="stylesheet" href="assets/wow/animate.css" />
    <link rel="stylesheet" href="assets/gallery/blueimp-gallery.min.css">
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link rel="icon" href="images/favicon.png" type="image/x-icon">
    <link rel="stylesheet" href="assets/style.css">

</head>

<nav class="navbar  navbar-default" role="navigation">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">navegação</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
     
      <a class="navbar-brand" href="index.php"><img src="images/logo-loja.png"></a>
    </div>

    <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
      
      <ul class="nav navbar-nav">        
      <ul class="nav navbar-nav">        
        <li><a href="index.php">Início</a></li>
        <li><a href="QuartoseSuites.php">Quartos e Suites</a></li>        
        <li><a href="Historia.php">Minha Historia</a></li>
        <li><a href="Galeria.php">Galeria</a></li>
        <li><a href="brinquedoteca.php">Brinquedoteca</a></li>
        <li><a href="cadastro.php">Cadastrar-se</a></li>
        <li><a href="entrar.php">Conectar-se</a></li>
        <li><a href="Contato.php">Contato</a></li>
      </ul>
      </ul>
    </div>
  </div>
</nav>
<br>
<body>
<section class="portfolio_section layout_padding">
      <div class="container">
        <br>
        <h2>
          LOGIN
        </h2>
        <p>
          Faça seu login aqui!
        </p>
       
           <?php
                    if(isset($_SESSION['nao_autenticado'])):
                    ?>
                    <div class="notification is-danger">
                      <p>ERRO: Usuário ou senha inválidos.</p>
                    </div>
                    <?php
                    endif;
                    unset($_SESSION['nao_autenticado']);//limpar a seção
                    ?>
                    <div class="box">
                        <form action="login.php" method="POST">
                            <div class="field">
                                <div class="control">
                                    <input name="usuario" name="text" class="input is-large" placeholder="Seu usuário" autofocus="">
                                </div>
                            </div>
<br>
                            <div class="field">
                                <div class="control">
                                    <input name="senha" class="input is-large" type="password" placeholder="Sua senha">
                                </div>
                            </div>
                            <br>
                            <button type="submit" href="css/style.css">
                              Entrar
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div> 
    </div>
    </section>
</body>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<footer class="spacer">
        <div class="container">
            <div class="row">
                <div class="col-sm-5">
                    <h4>Live Palace Hotel</h4>
                    <p>O melhor local em Barcelona, O Live Palace Hotel está localizado a apenas 50m do centro de Barcelona e dispõe de piscina ao ar livre com vista da cidade.</p>
                </div>              
                 
                 <div class="col-sm-3">
                    <h4>Principais links</h4>
                    <ul class="list-unstyled">
                    <li><a href="index.php">Início</a></li>
                    <li><a href="QuartosePreços.php">Quartos e Preços</a></li>        
                    <li><a href="Historia.php">Minha Historia</a></li>
                    <li><a href="Galeria.php">Galeria</a></li>
                    <li><a href="Contato.php">Contato</a></li>
                    </ul>
                </div>
                 <div class="col-sm-4 subscribe">
                    <h4>E-mail: </h4>
                    <div class="input-group">
                    <input type="text" class="form-control" placeholder="Digite o seu e-mail:">
                    <span class="input-group-btn">
                    <button class="btn btn-default" type="button">Enviar</button>
                    </span>
                    </div>
                    <div class="social">
                    <a href="#"><i class="fa fa-facebook-square" data-toggle="tooltip" data-placement="top" data-original-title="facebook"></i></a>
                    <a href="#"><i class="fa fa-instagram"  data-toggle="tooltip" data-placement="top" data-original-title="instragram"></i></a>
                    </div>
                </div>
            </div>
            <!--/.row--> 
        </div>
        <!--/.container-->    
    
    <!--/.footer-bottom--> 
</footer>

<div class="text-center copyright">Feito pela Programadora Larissa</a></div>

<a href="#home" class="toTop scroll"><i class="fa fa-angle-up"></i></a>




<!-- The Bootstrap Image Gallery lightbox, should be a child element of the document body -->
<div id="blueimp-gallery" class="blueimp-gallery blueimp-gallery-controls">
    <!-- The container for the modal slides -->
    <div class="slides"></div>
    <!-- Controls for the borderless lightbox -->
    <h3 class="title">title</h3>
    <a class="prev">‹</a>
    <a class="next">›</a>
    <a class="close">×</a>
    <!-- The modal dialog, which will be used to wrap the lightbox content -->    
</div>





<script src="assets/jquery.js"></script>

<!-- wow script -->
<script src="assets/wow/wow.min.js"></script>

<!-- uniform -->
<script src="assets/uniform/js/jquery.uniform.js"></script>


<!-- boostrap -->
<script src="assets/bootstrap/js/bootstrap.js" type="text/javascript" ></script>

<!-- jquery mobile -->
<script src="assets/mobile/touchSwipe.min.js"></script>

<!-- jquery mobile -->
<script src="assets/respond/respond.js"></script>

<!-- gallery -->
<script src="assets/gallery/jquery.blueimp-gallery.min.js"></script>


<!-- custom script -->
<script src="assets/script.js"></script>










</body>
</html>

</html>