<?php include 'header.php';?>
<div class="banner">    	   
    <img src="images/banner.png"  class="img-responsive" alt="slide">
    <div class="welcome-message">
        <div class="wrap-info">
            <div class="information">
                <h1  class="animated fadeInDown">Live Palace Hotel</h1>
                <p class="animated fadeInUp">Você tem a idade certa para ser feliz e a energia necessária para fazer da sua vida uma aventura inspiradora.</p>                
            </div>
            <a href="#information" class="arrow-nav scroll wowload fadeInDownBig"><i class="fa fa-angle-down"></i></a>
        </div>
    </div>
</div>

<div id="information" class="spacer reserve-info ">
<div class="container">
<div class="row">
<div class="col-sm-7 col-md-8">
    <div class="embed-responsive embed-responsive-16by9 wowload fadeInLeft"><iframe  class="embed-responsive-item" src="//player.vimeo.com/video/55057393?title=0" width="100%" height="400" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe></div>
</div>
<div class="col-sm-5 col-md-4">
<h3>Faça sua reserva</h3>
<form role="form" class="wowload fadeInRight">
        <div class="form-group">
            <input type="text" class="form-control"  placeholder="Nome">
        </div>
        <div class="form-group">
            <input type="email" class="form-control"  placeholder="E-mail">
        </div>
        <div class="form-group">
            <input type="Phone" class="form-control"  placeholder="Telefone/celular">
        </div>   
        <div class="form-group">
              
              <select class="form-control">
              <option>Número de quartos:</option>
              <option>1</option>
              <option>2</option>
              <option>3</option>
              <option>4</option>
              <option>5</option>
            </select>
            </div>     
        <div class="form-group">
            <div class="row">  
            <div class="col-xs-6">
            <select class="form-control">
              <option>Número de Criaças:</option>
              <option>1</option>
              <option>2</option>
              <option>3</option>
              <option>4</option>
              <option>5</option>
            </select>
            </div>        
            <div class="col-xs-6">
            <select class="form-control">
              <option>Numero adultos:</option>
              <option>1</option>
              <option>2</option>
              <option>3</option>
              <option>4</option>
              <option>5</option>
            </select>
            
          
          </div>
        </div>
        </div>
        <div class="form-group">
            <div class="row">
            <div class="col-xs-4">
              <select class="form-control col-sm-2" name="expiry-month" id="expiry-month">
                <option>Data</option>
                <option value="01">01</option>
                <option value="02">02</option>
                <option value="03">03</option>
                <option value="04">04</option>
                <option value="05">05</option>
                <option value="06">06</option>
                <option value="07">07</option>
                <option value="08">08</option>
                <option value="09">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
              </select>
            </div>
            <div class="col-xs-4">
              <select class="form-control col-sm-2" name="expiry-month" id="expiry-month">
                <option>Mês</option>
                <option value="01">Jan</option>
                <option value="02">Feb</option>
                <option value="03">Mar</option>
                <option value="04">Apr</option>
                <option value="05">May</option>
                <option value="06">June</option>
                <option value="07">July</option>
                <option value="08">Aug</option>
                <option value="09">Sep</option>
                <option value="10">Oct</option>
                <option value="11">Nov</option>
                <option value="12">Dec</option>
              </select>
            </div>
            <div class="col-xs-4">
              <select class="form-control" name="expiry-year">
              <option>Ano</option>
                <option value="13">2022</option>
                <option value="14">2023</option>
                <option value="15">2024</option>
                <option value="16">2025</option>
                <option value="17">2026</option>
                <option value="18">2027</option>
                <option value="19">2028</option>
                <option value="20">2029</option>
                <option value="21">2030</option>
              </select>
            </div>
          </div>
        </div>
        <div class="form-group">
            <textarea class="form-control"  placeholder="Mensagem" rows="4"></textarea>
        </div>
        <button class="btn btn-default">Enviar a reserva</button>
    </form>    
</div>
</div>  
</div>
</div>
<!-- reservation-information -->

<!-- services -->
<div class="spacer services wowload fadeInUp">
<div class="container">
    <div class="row">
        <div class="col-sm-4">
            <!-- RoomCarousel -->
            <div id="RoomCarousel" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                <div class="item active"><img src="images/quartoesuite (1).jpg" class="img-responsive" alt="slide"></div>
                <div class="item  height-full"><img src="images/quartoesuite (2).jpg"  class="img-responsive" alt="slide"></div>
                <div class="item  height-full"><img src="images/quartoesuite (3).jpg"  class="img-responsive" alt="slide"></div>
                <div class="item  height-full"><img src="images/quartoesuite (4).jpg"  class="img-responsive" alt="slide"></div>
                <div class="item  height-full"><img src="images/quartoesuite (5).jpg"  class="img-responsive" alt="slide"></div>
                <div class="item  height-full"><img src="images/quartoesuite (6).jpg"  class="img-responsive" alt="slide"></div>
                </div>
                <!-- Controls -->
                <a class="left carousel-control" href="#RoomCarousel" role="button" data-slide="prev"><i class="fa fa-angle-left"></i></a>
                <a class="right carousel-control" href="#RoomCarousel" role="button" data-slide="next"><i class="fa fa-angle-right"></i></a>
            </div>
            <!-- RoomCarousel-->
            <div class="caption">Quarto e Suite<a href="Galeria.php" class="pull-right"><i class="fa fa-edit"></i></a></div>
        </div>


        <div class="col-sm-4">
            <!-- RoomCarousel -->
            <div id="TourCarousel" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                <div class="item active"><img src="images/comida (4).jpg" class="img-responsive" alt="slide"></div>
                <div class="item  height-full"><img src="images/comida (1).jpg"  class="img-responsive" alt="slide"></div>
                <div class="item  height-full"><img src="images/comida (5).jpg"  class="img-responsive" alt="slide"></div>
                <div class="item  height-full"><img src="images/comida (2).jpg"  class="img-responsive" alt="slide"></div>
                <div class="item  height-full"><img src="images/comida (3).jpg"  class="img-responsive" alt="slide"></div>
                <div class="item  height-full"><img src="images/comida (6).jpg"  class="img-responsive" alt="slide"></div>
                <div class="item  height-full"><img src="images/comida (7).jpg"  class="img-responsive" alt="slide"></div>
                <div class="item  height-full"><img src="images/comida (8).jpg"  class="img-responsive" alt="slide"></div>
                </div>
                <!-- Controls -->
                <a class="left carousel-control" href="#TourCarousel" role="button" data-slide="prev"><i class="fa fa-angle-left"></i></a>
                <a class="right carousel-control" href="#TourCarousel" role="button" data-slide="next"><i class="fa fa-angle-right"></i></a>
            </div>
            <!-- RoomCarousel-->
            <div class="caption">Restaurante <a href="Galeria.php" class="pull-right"><i class="fa fa-edit"></i></a></div>
        </div>


        <div class="col-sm-4">
            <!-- RoomCarousel -->
            <div id="FoodCarousel" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                <div class="item active"><img src="images/lazer (3).jpg" class="img-responsive" alt="slide"></div>
                <div class="item  height-full"><img src="images/lazer (4).jpg"  class="img-responsive" alt="slide"></div>
                <div class="item  height-full"><img src="images/lazer (5).jpg"  class="img-responsive" alt="slide"></div>
                <div class="item  height-full"><img src="images/lazer (2).jpg"  class="img-responsive" alt="slide"></div>
                </div>
                <!-- Controls -->
                <a class="left carousel-control" href="#FoodCarousel" role="button" data-slide="prev"><i class="fa fa-angle-left"></i></a>
                <a class="right carousel-control" href="#FoodCarousel" role="button" data-slide="next"><i class="fa fa-angle-right"></i></a>
            </div>
            <!-- RoomCarousel-->
            <div class="caption">Lazer<a href="Galeria.php" class="pull-right"><i class="fa fa-edit"></i></a></div>
        </div>
    </div>
</div>
</div>
<!-- services -->


<?php include 'footer.php';?>