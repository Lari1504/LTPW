<?php include 'header.php';?>
<div class="container">

       <h1 class="title">Live Palace Hotel</h1>
       <div class="row">
              <div class="col-sm-4"><p>O melhor local em Barcelona, O Live Palace Hotel está localizado a apenas 50m do centro de Barcelona e dispõe de piscina ao ar livre com vista da cidade.</p><br>
              <p>Ele oferece os melhores passeios turísticos, contém uma academia para os marombas de plantão, um bar com todos os tipos de bebidas que fica localizado junto a piscina externa, uma piscina aquecida interna em uma de nossas suites,uma brinquedoteca para a criançada, e sem contar nas melhores comidas caseiras do restaurante, uma sauna, e um spa pra quem quiser relaxar.</p><br>
              <p>Aproveite também e faça sua reserva não fique de fora traga sua família e amigos ficaremos felizes de recebelos em nosso maravilhoso hotel!</p>
              </div>              
       </div>


       <div class="spacer">
       <div class="embed-responsive embed-responsive-16by9"><iframe  class="embed-responsive-item" src="//player.vimeo.com/video/55057393?title=0" width="100%" height="400" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe></div>
       </div>




</div>
<?php include 'footer.php';?>