<?php include 'header.php';?>
<div class="container">

       <h1 class="title">Gallery</h1>
       <div class="row gallery">
              <div class="col-sm-4 wowload fadeInUp"><a href="images/comida (1).jpg" title="Foods" class="gallery-image" data-gallery><img src="images/comida (1).jpg" class="img-responsive"></a></div>
              <div class="col-sm-4 wowload fadeInUp"><a href="images/comida (2).jpg" title="Coffee" class="gallery-image" data-gallery><img src="images/comida (2).jpg" class="img-responsive"></a></div>
              <div class="col-sm-4 wowload fadeInUp"><a href="images/comida (3).jpg" title="Travel" class="gallery-image" data-gallery><img src="images/comida (3).jpg" class="img-responsive"></a></div>
              <div class="col-sm-4 wowload fadeInUp"><a href="images/comida (4).jpg" title="Adventure" class="gallery-image" data-gallery><img src="images/comida (4).jpg" class="img-responsive"></a></div>
              <div class="col-sm-4 wowload fadeInUp"><a href="images/comida (5).jpg" title="Fruits" class="gallery-image" data-gallery><img src="images/comida (5).jpg" class="img-responsive"></a></div>
              <div class="col-sm-4 wowload fadeInUp"><a href="images/comida (6).jpg" title="Summer" class="gallery-image" data-gallery><img src="images/comida (6).jpg" class="img-responsive"></a></div>
              <div class="col-sm-4 wowload fadeInUp"><a href="images/comida (7).jpg" title="Bathroom" class="gallery-image" data-gallery><img src="images/comida (7).jpg" class="img-responsive"></a></div>
              <div class="col-sm-4 wowload fadeInUp"><a href="images/comida (8).jpg" title="Rooms" class="gallery-image" data-gallery><img src="images/comida (8).jpg" class="img-responsive"></a></div>
              <div class="col-sm-4 wowload fadeInUp"><a href="images/lazer (2).jpg" title="Big Room" class="gallery-image" data-gallery><img src="images/lazer (2).jpg" class="img-responsive"></a></div>
              <div class="col-sm-4 wowload fadeInUp"><a href="images/lazer (3).jpg" title="Living Room" class="gallery-image" data-gallery><img src="images/lazer (3).jpg" class="img-responsive"></a></div>
              <div class="col-sm-4 wowload fadeInUp"><a href="images/lazer (4).jpg" title="Fruits" class="gallery-image" data-gallery><img src="images/lazer (4).jpg" class="img-responsive"></a></div>
              <div class="col-sm-4 wowload fadeInUp"><a href="images/lazer (5).jpg" title="Travel" class="gallery-image" data-gallery><img src="images/lazer (5).jpg" class="img-responsive"></a></div>
       </div>
</div>
<?php include 'footer.php';?>