<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>Live Palace Hotel</title>
<link href='http://fonts.googleapis.com/css?family=Raleway:300,500,800|Old+Standard+TT' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Raleway:300,500,800' rel='stylesheet' type='text/css'>

<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />
<link type="text/css" rel="stylesheet" href="assets/uniform/css/uniform.default.min.css" />
<link rel="stylesheet" href="assets/wow/animate.css" />
<link rel="stylesheet" href="assets/gallery/blueimp-gallery.min.css">
<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">
<link rel="stylesheet" href="assets/style.css">

</head>

<body id="home">

<nav class="navbar  navbar-default" role="navigation">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">navegação</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
     
      <a class="navbar-brand" href="index.php"><img src="images/logo-loja.png"></a>
    </div>

    <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
      
      <ul class="nav navbar-nav">        
      <ul class="nav navbar-nav">        
        <li><a href="index.php">Início</a></li>
        <li><a href="QuartoseSuites.php">Quartos e Suites</a></li>        
        <li><a href="Historia.php">Minha Historia</a></li>
        <li><a href="Galeria.php">Galeria</a></li>
        <li><a href="brinquedoteca.php">Brinquedoteca</a></li>
        <li><a href="cadastro.php">Cadastrar-se</a></li>
        <li><a href="entrar.php">Conectar</a></li>
        <li><a href="Contato.php">Contato</a></li>
      </ul>
      </ul>
    </div>
  </div>
</nav>