<?php include 'header.php';?>
<div class="container">

       <h1 class="title">Brinquedoteca</h1>
       <div class="row">
              <div class="col-sm-4"><p>Temos dois tipos de bliquedotecas para crianças entre 1 a 10 anos</p><p>Valores: <br> (Durante o Dia): Acesso livre <br> (Durante a Noite): Taxa de €15 com direito a babá
              </p></div>              
       </div>
       
       <div>
       <div class="col-sm-4 wowload fadeInUp"><a href="images/briquedoteca (1).jpeg" title="Foods" class="gallery-image" data-gallery><img src="images/briquedoteca (1).jpeg" class="img-responsive"></a></div>
       <div class="col-sm-4 wowload fadeInUp"><a href="images/briquedoteca (2).jpeg" title="Coffee" class="gallery-image" data-gallery><img src="images/briquedoteca (2).jpeg" class="img-responsive"></a></div>
       <br>
</div>

<br>

</div>
<?php include 'footer.php';?>