package com.example.livepalace;

public class ConsultarDadosActivity {
}
