package com.example.livepalace;

public class LoginActivity {
}
