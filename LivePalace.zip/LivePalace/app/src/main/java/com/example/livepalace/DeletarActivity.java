package com.example.livepalace;

public class DeletarActivity {
}
